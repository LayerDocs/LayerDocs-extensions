import subprocess
import sys
import os
import urllib.request
import zipfile
import shutil
import glob

class LayerDocs:
    """The Ultimate LayerDocs Wrapper for Local and Cloud (v0.2.3)."""
    
    ENGINE_URL = "https://github.com/LayerDocs/LayerDocs-core/releases/latest/download/layerdocs.zip"
    
    def __init__(self, cli_path=None):
        self.cli_path = cli_path or self._find_or_install_engine()

    def _find_or_install_engine(self):
        # 1. Check if it is already in the system PATH
        if shutil.which("layerdocs"):
            return "layerdocs"
        
        # 2. Check the standard installation folder
        app_data = os.path.join(os.path.expanduser("~"), ".layerdocs")
        
        # We look for 'layerdocs' or 'layerdocs.bat' anywhere inside .layerdocs/
        bin_name = "layerdocs.bat" if os.name == "nt" else "layerdocs"
        pattern = os.path.join(app_data, "**", bin_name)
        matches = [f for f in glob.glob(pattern, recursive=True) if os.path.isfile(f)]
        
        if matches:
            return matches[0]
            
        # 3. If still not found, Download it automatically
        return self.download_engine()

    def download_engine(self):
        """Forces a download of the LayerDocs engine."""
        app_data = os.path.join(os.path.expanduser("~"), ".layerdocs")
        print(f"🚀 LayerDocs Engine not found. Installing to {app_data}...")
        
        if os.path.exists(app_data): shutil.rmtree(app_data)
        os.makedirs(app_data, exist_ok=True)
        zip_path = os.path.join(app_data, "engine.zip")
        
        try:
            # Download with a browser-like User-Agent
            req = urllib.request.Request(self.ENGINE_URL, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req) as response, open(zip_path, "wb") as out_file:
                shutil.copyfileobj(response, out_file)
                
            # Extract
            with zipfile.ZipFile(zip_path, "r") as zip_ref:
                zip_ref.extractall(app_data)
            os.remove(zip_path)
            
            # Find the binary in the newly extracted files
            bin_name = "layerdocs.bat" if os.name == "nt" else "layerdocs"
            pattern = os.path.join(app_data, "**", bin_name)
            matches = [f for f in glob.glob(pattern, recursive=True) if os.path.isfile(f)]
            
            if matches:
                new_bin = matches[0]
                if os.name != "nt":
                    os.chmod(new_bin, 0o755) # Make executable on Linux/Mac/Colab
                print(f"✅ Engine installed successfully!")
                return new_bin
            else:
                raise FileNotFoundError("Could not find binary inside the downloaded zip.")
                
        except Exception as e:
            print(f"❌ Installation failed: {e}")
            print("Falling back to manual 'layerdocs' command...")
            return "layerdocs"

    def compile(self, file_path, output_dir=None):
        """Compiles a .qd file using the LayerDocs CLI."""
        cmd = [self.cli_path, "c", file_path]
        if output_dir:
            cmd.extend(["-o", output_dir])
        return subprocess.run(cmd, capture_output=True, text=True)

def main():
    """CLI Entry point."""
    ld = LayerDocs()
    subprocess.run([ld.cli_path] + sys.argv[1:])
