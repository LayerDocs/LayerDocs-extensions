# LayerDocs: Modular & Deep Typesetting 🚀

[![PyPI version](https://img.shields.io/pypi/v/layerdocs.svg)](https://pypi.org/project/layerdocs/)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

**LayerDocs** is a next-generation typesetting system that combines the simplicity of Markdown with the power of modular programming. It is designed for developers who need more depth than standard Markdown but want something more modern than LaTeX.

## ✨ Key Features

- 🧩 **Modular Syntax**: Use `.function { content }` to build complex layouts.
- 🎨 **Premium Themes**: Built-in support for professional PDF and HTML outputs.
- 🐍 **Python Powered**: Full CLI and API support for Python workflows.
- ⚡ **Auto-Engine**: Automatically manages the underlying Kotlin typesetting engine.

## 📥 Installation

```bash
pip install layerdocs
```

## 🚀 Quick Start

### 1. Create a Document (`main.qd`)
```markdown
# Welcome to LayerDocs

.box(title="Note") {
    This is a modular component rendered with LayerDocs!
}

!(50%)[Logo](https://raw.githubusercontent.com/LayerDocs/LayerDocs-core/main/src/main/resources/assets/images/logo.png)
```

### 2. Compile via CLI
```bash
python -m layerdocs c main.qd
```

### 3. Use in Python
```python
from layerdocs import LayerDocs

ld = LayerDocs()
ld.compile("main.qd", output_dir="dist")
```

## 🛠️ Advanced Usage

LayerDocs supports:
- **Math**: Full KaTeX integration.
- **Diagrams**: Native Mermaid.js support.
- **Themes**: Customizable CSS-based layouts.

## 👨‍💻 Author
Created and maintained by **SatyamPote**.

## 📄 License
This project is licensed under the GNU GPLv3 License.
